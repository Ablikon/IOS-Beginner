import Foundation

struct Product {
    let id: String
    let name: String
    let price: Double
    let category: Category
    let description: String

    enum Category: String {
        case electronics, clothing, food, books
    }

    private static let currencyFormatter: NumberFormatter = {
        let f = NumberFormatter()
        f.numberStyle = .currency
        f.locale = Locale(identifier: "en_US")
        return f
    }()

    var displayPrice: String {
        let ns = NSNumber(value: price)
        return Product.currencyFormatter.string(from: ns) ?? String(format: "$%.2f", price)
    }

    init?(id: String = UUID().uuidString,
          name: String,
          price: Double,
          category: Category,
          description: String) {
        guard price > 0 else { return nil }
        self.id = id
        self.name = name
        self.price = price
        self.category = category
        self.description = description
    }
}

struct CartItem {
    let product: Product
    private(set) var quantity: Int

    init(product: Product, quantity: Int) {
        self.product = product
        self.quantity = max(1, quantity)
    }

    var subtotal: Double {
        product.price * Double(quantity)
    }

    mutating func updateQuantity(_ newQuantity: Int) {
        guard newQuantity > 0 else { return }
        quantity = newQuantity
    }

    mutating func increaseQuantity(by amount: Int) {
        guard amount > 0 else { return }
        quantity += amount
    }
}

class ShoppingCart {
    private(set) var items: [CartItem] = []
    var discountCode: String?

    init() {}

    func addItem(product: Product, quantity: Int = 1) {
        guard quantity > 0 else { return }
        if let idx = items.firstIndex(where: { $0.product.id == product.id }) {
            items[idx].increaseQuantity(by: quantity)
        } else {
            items.append(CartItem(product: product, quantity: quantity))
        }
    }

    func removeItem(productId: String) {
        items.removeAll { $0.product.id == productId }
    }

    func updateItemQuantity(productId: String, quantity: Int) {
        if quantity == 0 {
            removeItem(productId: productId)
            return
        }
        guard quantity > 0 else { return }
        guard let idx = items.firstIndex(where: { $0.product.id == productId }) else { return }
        items[idx].updateQuantity(quantity)
    }

    func clearCart() {
        items.removeAll()
    }

    var subtotal: Double {
        items.reduce(0) { $0 + $1.subtotal }
    }

    var discountAmount: Double {
        guard let code = discountCode?.trimmingCharacters(in: .whitespacesAndNewlines).uppercased(),
              subtotal > 0 else { return 0 }
        switch code {
        case "SAVE10": return subtotal * 0.10
        case "SAVE20": return subtotal * 0.20
        default: return 0
        }
    }

    var total: Double {
        max(0, subtotal - discountAmount)
    }

    var itemCount: Int {
        items.reduce(0) { $0 + $1.quantity }
    }

    var isEmpty: Bool {
        items.isEmpty
    }
}

struct Address {
    let street: String
    let city: String
    let zipCode: String
    let country: String

    var formattedAddress: String {
        "\(street)\n\(city), \(zipCode)\n\(country)"
    }
}

struct Order {
    let orderId: String
    let items: [CartItem]
    let subtotal: Double
    let discountAmount: Double
    let total: Double
    let timestamp: Date
    let shippingAddress: Address

    init(from cart: ShoppingCart, shippingAddress: Address) {
        self.orderId = UUID().uuidString
        self.items = cart.items
        self.subtotal = cart.subtotal
        self.discountAmount = cart.discountAmount
        self.total = cart.total
        self.timestamp = Date()
        self.shippingAddress = shippingAddress
    }

    var itemCount: Int {
        items.reduce(0) { $0 + $1.quantity }
    }
}

let laptop = Product(
    id: "P1",
    name: "Macbook Pro 14\"",
    price: 1299.99,
    category: .electronics,
    description: "Powerful laptop for work and study"
)!
let book = Product(
    id: "P2",
    name: "The easy way to stop smoking by Allen Carr",
    price: 39.99,
    category: .books,
    description: "useful book to quit nicotine"
)!
let headphones = Product(
    id: "P3",
    name: "Airpods pro",
    price: 199.99,
    category: .electronics,
    description: "Over-ear ANC headphones"
)!

print("Laptop price:", laptop.displayPrice)

let cart = ShoppingCart()
cart.addItem(product: laptop, quantity: 1)
cart.addItem(product: book, quantity: 2)

cart.addItem(product: laptop, quantity: 1)
if let laptopItem = cart.items.first(where: { $0.product.id == laptop.id }) {
    print("Laptop quantity now:", laptopItem.quantity)
}

print("Subtotal:", String(format: "%.2f", cart.subtotal))
print("Item count:", cart.itemCount)

cart.discountCode = "SAVE10"
print("Total with discount:", String(format: "%.2f", cart.total))

cart.removeItem(productId: book.id)
print("Item count after removing book:", cart.itemCount)

func modifyCart(_ cart: ShoppingCart) {
    cart.addItem(product: headphones, quantity: 1)
}
modifyCart(cart)
print("Item count after modifyCart:", cart.itemCount)

let item1 = CartItem(product: laptop, quantity: 1)
var item2 = item1
item2.updateQuantity(5)
print("item1 qty:", item1.quantity, "| item2 qty:", item2.quantity)

let address = Address(street: "2 mircodisctrict, 25", city: "Almaty", zipCode: "050000", country: "Kazakhstan")
let order = Order(from: cart, shippingAddress: address)

cart.clearCart()
print("Order items count:", order.itemCount)
print("Cart items count:", cart.itemCount)

print("Ship to:\n\(order.shippingAddress.formattedAddress)")
print("Order at:", order.timestamp)
