// Task 1
for number in 1...100 {
    if number % 15 == 0 {
        print("FizzBuzz")
    }
    else if number % 3 == 0 {
        print("Fizz")
    }
    else if number % 5 == 0 {
        print("Buzz")
    }
    else {
        print(number)
    }
}

// Task 2
func isPrime(_ number: Int) -> Bool {
    if number < 2 {
        return false
    }
    
    for i in 2..<Int(Double(number).squareRoot()) + 1 {
        if number % i == 0 {
            return false
        }
    }
    return true
}

print("Prime numbers between 1 and 100:")
for number in 1...100 {
    if isPrime(number) {
        print(number)
    }
}

// Task 3
func celsiusToFahrenheit(_ celsius: Double) -> Double {
    return (celsius * 9/5) + 32
}

func celsiusToKelvin(_ celsius: Double) -> Double {
    return celsius + 273.15
}

func fahrenheitToCelsius(_ fahrenheit: Double) -> Double {
    return (fahrenheit - 32) * 5/9
}

func fahrenheitToKelvin(_ fahrenheit: Double) -> Double {
    return celsiusToKelvin(fahrenheitToCelsius(fahrenheit))
}

func kelvinToCelsius(_ kelvin: Double) -> Double {
    return kelvin - 273.15
}

func kelvinToFahrenheit(_ kelvin: Double) -> Double {
    return celsiusToFahrenheit(kelvinToCelsius(kelvin))
}

let temperature = 25.0
let unit = "C"

if unit == "C" {
    let fahrenheit = celsiusToFahrenheit(temperature)
    let kelvin = celsiusToKelvin(temperature)
    print("Temperature: \(temperature)°C")
    print("In Fahrenheit: \(fahrenheit)°F")
    print("In Kelvin: \(kelvin)K")
}
else if unit == "F" {
    let celsius = fahrenheitToCelsius(temperature)
    let kelvin = fahrenheitToKelvin(temperature)
    print("Temperature: \(temperature)°F")
    print("In Celsius: \(celsius)°C")
    print("In Kelvin: \(kelvin)K")
}
else if unit == "K" {
    let celsius = kelvinToCelsius(temperature)
    let fahrenheit = kelvinToFahrenheit(temperature)
    print("Temperature: \(temperature)K")
    print("In Celsius: \(celsius)°C")
    print("In Fahrenheit: \(fahrenheit)°F")
}

import Foundation

// Task 4
func shoppingListDemo() {
    var shoppingList: [String] = []

    func addItem(_ item: String) {
        shoppingList.append(item)
        print("Added '\(item)' to shopping list")
    }

    func removeItem(_ item: String) {
        if let index = shoppingList.firstIndex(of: item) {
            shoppingList.remove(at: index)
            print("Removed '\(item)' from shopping list")
        } else {
            print("Item '\(item)' not found in shopping list")
        }
    }

    func displayList() {
        if shoppingList.isEmpty {
            print("Shopping list is empty")
        } else {
            print("Shopping List:")
            for i in 0..<shoppingList.count {
                print("\(i + 1). \(shoppingList[i])")
            }
        }
    }

    addItem("Milk")
    addItem("Bread")
    addItem("Eggs")
    displayList()
    removeItem("Bread")
    displayList()
}

shoppingListDemo()

// Task 5
func countWordFrequency(_ sentence: String) -> [String: Int] {
    var wordCount: [String: Int] = [:]
    
    let lowercaseSentence = sentence.lowercased()
    var cleanedSentence = ""
    
    for char in lowercaseSentence {
        if char.isLetter || char.isWhitespace {
            cleanedSentence.append(char)
        }
    }
    
    let words = cleanedSentence.split(separator: " ").map { String($0) }
    
    for word in words {
        if !word.isEmpty {
            wordCount[word, default: 0] += 1
        }
    }
    
    return wordCount
}

let sentence = "Hello world! Hello Swift. World of Swift programming."
let frequencies = countWordFrequency(sentence)

print("Word frequencies:")
for (word, count) in frequencies {
    print("\(word): \(count)")
}

//Task 6
func fibonacci(_ n: Int) -> [Int] {
    if n <= 0 {
        return []
    }
    if n == 1 {
        return [0]
    }
    if n == 2 {
        return [0, 1]
    }
    
    var sequence = [0, 1]
    
    for _ in 2..<n {
        let next = sequence[sequence.count - 1] + sequence[sequence.count - 2]
        sequence.append(next)
    }
    
    return sequence
}

let fibSequence = fibonacci(10)
print("First 10 Fibonacci numbers: \(fibSequence)")

// Task 7
let students = ["Alice": 85, "Bob": 92, "Charlie": 78, "Diana": 95, "Eve": 88]

var totalScore = 0
var highestScore = 0
var lowestScore = 100
var highestStudent = ""
var lowestStudent = ""

for (name, score) in students {
    totalScore += score
    
    if score > highestScore {
        highestScore = score
        highestStudent = name
    }
    
    if score < lowestScore {
        lowestScore = score
        lowestStudent = name
    }
}

let average = Double(totalScore) / Double(students.count)

print("Grade Report:")
print("Average score: \(average)")
print("Highest score: \(highestScore) (\(highestStudent))")
print("Lowest score: \(lowestScore) (\(lowestStudent))")
print("\nStudent Performance:")

for (name, score) in students {
    let status = Double(score) >= average ? "Above Average" : "Below Average"
    print("\(name): \(score) - \(status)")
}

// Task 8
func isPalindrome(_ text: String) -> Bool {
    var cleanText = ""
    
    for char in text.lowercased() {
        if char.isLetter {
            cleanText.append(char)
        }
    }
    
    return cleanText == String(cleanText.reversed())
}

let testStrings = ["A man, a plan, a canal: Panama", "race a car", "hello", "Madam"]
for testString in testStrings {
    print("'\(testString)' is palindrome: \(isPalindrome(testString))")
}

// Task 9
func add(_ a: Double, _ b: Double) -> Double {
    return a + b
}

func subtract(_ a: Double, _ b: Double) -> Double {
    return a - b
}

func multiply(_ a: Double, _ b: Double) -> Double {
    return a * b
}

func divide(_ a: Double, _ b: Double) -> Double? {
    if b == 0 {
        return nil
    }
    return a / b
}

func calculator() {
    let num1 = 10.0
    let num2 = 5.0
    let operation = "+"
    
    switch operation {
    case "+":
        print("\(num1) + \(num2) = \(add(num1, num2))")
    case "-":
        print("\(num1) - \(num2) = \(subtract(num1, num2))")
    case "*":
        print("\(num1) * \(num2) = \(multiply(num1, num2))")
    case "/":
        if let result = divide(num1, num2) {
            print("\(num1) / \(num2) = \(result)")
        } else {
            print("Error: Division by zero")
        }
    default:
        print("Invalid operation")
    }
}

calculator()

// Task 10
func hasUniqueCharacters(_ text: String) -> Bool {
    var seenCharacters: Set<Character> = []
    
    for character in text {
        if seenCharacters.contains(character) {
            return false
        }
        seenCharacters.insert(character)
    }
    
    return true
}

let testWords = ["hello", "world", "swift", "unique", "abcdef"]
for word in testWords {
    print("'\(word)' has unique characters: \(hasUniqueCharacters(word))")
}
